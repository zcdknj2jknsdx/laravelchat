<?php echo e($slot); ?>

<?php /**PATH D:\app_chat\chat-app-laravel-pusher\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>