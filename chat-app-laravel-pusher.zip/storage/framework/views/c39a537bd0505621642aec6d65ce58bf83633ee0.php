[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\app_chat\chat-app-laravel-pusher\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>